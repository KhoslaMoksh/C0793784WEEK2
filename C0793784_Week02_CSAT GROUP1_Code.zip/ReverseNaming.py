def ReverseNaming():

    first_name=input("Enter your first name: ")
    last_name=input("Enter your Last name:" )

    print("the reversed name is as follow: ")

    print("Greetings "+ last_name + " "+ first_name)

    print("---------------------------")

