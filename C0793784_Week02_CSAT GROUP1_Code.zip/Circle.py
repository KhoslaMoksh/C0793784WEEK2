def Area():

    radius=float(input("Enter radius: "))
    area=3.14*radius*radius;
    print(f"Area of circle is: {area}")